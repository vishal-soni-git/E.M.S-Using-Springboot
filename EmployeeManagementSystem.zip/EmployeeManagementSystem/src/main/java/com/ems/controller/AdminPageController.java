package com.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ems.entities.EmployeeLeave;
import com.ems.service.EmployeeLeaveService;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
@RequestMapping("/admin")
public class AdminPageController {

    @Autowired
    EmployeeLeaveService employeeLeaveService;

    @GetMapping("/AdminDashboard")
    public String adminDashboard() {
        return "AdminDashboard";
    }

    @GetMapping("/leaveManagement")
    public String leaveManagement(Model model) {
        return "AdminLeaveManagement";
    }

    //creating for geting data from db to html page
    @ModelAttribute("employeeleaves")
    public List<EmployeeLeave> getEmployeeLeaves() {
        return employeeLeaveService.getAllByIdDesc();
    }

    @PostMapping("/leaveManagement/process")
    public String postMethodName(@RequestParam("action") String action, @RequestParam("requestId") String empId) {

        EmployeeLeave employeeLeave=employeeLeaveService.getEmployeeById(Integer.parseInt(empId));
       
        if(action.equals("accept"))
        {
            employeeLeave.setStatus("ACCEPT");
            System.out.println("Accept leave");
        }
        else if (action.equals("reject")) {
            employeeLeave.setStatus("REJECT");
            System.out.println("Reject Leaves");
        }
        else{
            System.out.println("some error action not found");
        }

        employeeLeaveService.save(employeeLeave);
        
        return "/AdminLeaveManagement";
    }
    

    @GetMapping("/uploadUpdates")
    public String getMethodName() {
        return "UploadUpdates";
    } 

}
