package com.ems.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ems.entities.Employee;
import com.ems.entities.EmployeeLeave;
import com.ems.service.EmployeeLeaveService;
import com.ems.service.EmployeeService;

import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.PostMapping;



@Controller
@RequestMapping("/employee")
public class EmployeePageController {

    @Autowired
    EmployeeService es;
    
    @Autowired
    EmployeeLeaveService employeeLeaveService;


    @GetMapping("/EmployeeDashboard")
    public String employeeDashboard() {
        return "EmployeeDashboard"; // dashboard.html in templates folder
    }

    @GetMapping("/EmployeeProfile")
    public String employeeProfile(HttpSession session, Model model) {

        String employeeEmail=(String) session.getAttribute("employeeEmail");

        System.out.println("Comes in profile page");

        System.out.println("There are session in profile page:-  "+employeeEmail);

        if (employeeEmail != null) {
            List<Employee> l=es.getEmployeeByEmail(employeeEmail);
            System.out.println("Fetched data for profile page "+l);

            if (!l.isEmpty()) {
                Employee emp = l.get(0); // Assuming the employee is unique by email
                // Convert the photo to base64
                String base64Photo = emp.getPhoto() != null ? Base64.getEncoder().encodeToString(emp.getPhoto()) : null;
               // emp.setPhoto(base64Photo);  // Set the base64 encoded photo
                model.addAttribute("employee", emp);  // Add the single employee object (not list) to model
                model.addAttribute("image", base64Photo);
            }
          
          //  model.addAttribute("employee", l);
            return "EmployeeProfile"; // Return profile view
        }
        return "redirect:/login";
    }

    
    @ModelAttribute("EmployeeLeaves")
    public List<EmployeeLeave> getEmployeeLeaves(HttpSession session) {

        List<Employee> emp= es.getEmployeeByEmail((String)session.getAttribute("employeeEmail"));

        System.out.println("  id emp in leave page "+emp.get(0).getId());

        List<EmployeeLeave> list=employeeLeaveService.getByEmployeeIdSortedDesc(emp.get(0).getId());

        return list;
    }

     @GetMapping("/EmployeeLeave")
    public String employeeLeave(Model model) {
      //  model.addAttribute("employeeLeaves", employeeLeaveService.getAllByIdDesc());
        return "EmployeeLeave";  // Refers to EmployeeLeave.html in templates
    }

    @PostMapping("/EmployeeLeave/process")
    public String postMethodName(@ModelAttribute EmployeeLeave employeeLeave, Model model) {
        System.out.println("Employee Leave Data ...  " + employeeLeave);

        if (employeeLeave.getStatus() == null) {
            employeeLeave.setStatus("PENDING");
        }

        employeeLeaveService.save(employeeLeave);
        System.out.println("......................Employee Leave Data saved....................");

        return "redirect:/employee/EmployeeLeave"; // Redirect to GET endpoint
    }
    

    @GetMapping("/EmployeeAttendence")
    public String employeeAttendence() {
        return "EmployeeAttendence";
    }

    @GetMapping("/EmployeeUpdates")
    public String employeeUpdates() {
        return "EmployeeUpdates";
    }

    @GetMapping("/resetPassword")
    public String getMethodName() {
        return "ResetPassword";
    }

}
